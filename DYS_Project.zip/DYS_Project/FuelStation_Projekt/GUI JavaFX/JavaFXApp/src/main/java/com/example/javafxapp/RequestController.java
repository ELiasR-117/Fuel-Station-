package com.example.javafxapp;

import javafx.application.Application;
import javafx.application.HostServices;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.regex.Pattern;


// Aufrufcontroller zur Verarbeitung der onClick Actions im GUI.
public class RequestController extends Application {
    @FXML
    private Button gatherDataButton;
    @FXML
    private Button downloadInvoiceButton;
    @FXML
    private TextField customerIdField1;
    @FXML
    private TextField customerIdField2;
    @FXML
    private Label invoiceInfo;
    @FXML
    private TextArea responseCreationInvoice;


    @FXML
    public void initialize() {
        //Initialisierung der Button onClick Events, entweder wird die ID genommen um initial
        // eine Invoice-PDF zu erzeugen oder man kann die Invoices downloaden.
        // Hierzu muss natürlich ein absoluter Pfad hinterlegt werden.
        gatherDataButton.setOnAction(event -> gatherData(customerIdField1.getText()));
        downloadInvoiceButton.setOnAction(event -> downloadInvoice(customerIdField2.getText()));

    }

    @FXML
    private void gatherData(String id) {
        //Falls eine ID gepflegt ist und diese numerisch ist.
        if (!id.isEmpty() && Pattern.matches("^[0-9]+$", id)) {

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(String.format("http://localhost:8080/invoices/%s", id)))
                    .POST(HttpRequest.BodyPublishers.ofString(id))
                    .build();

            try {
                client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                        .thenApply(HttpResponse::body)
                        // runLater, damit sich die Buttons in den aufgerufenen Funktionen nicht überlappen!
                        .thenAccept(body -> Platform.runLater(() -> invoiceInfo.setText(body)))
                        .join();
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (id.isEmpty()) {
            // Error-Handling, falls das Feld leer bleibt.
            invoiceInfo.setText("Error, Field is empty");
        } else {
            // Falls eine nicht-numerische Texteingabe erfolgt.
            invoiceInfo.setText("The field should only contain numeric Values");
        }
    }

    private void downloadInvoice(String id) {
        // Falls der zweite Button angeklickt wird und die ID numerisch ist.
        if (!id.isEmpty() && Pattern.matches("^[0-9]+$", id)) {

            //Retourniert einen neuen HTTP-Client mit Standard-Settings
            HttpClient client = HttpClient.newHttpClient();
            // Neue Instanz eines HTTP-Request Builders
            HttpRequest getRequest = HttpRequest.newBuilder()
                    // Erzeugen einer neuen Website (URI) im String-Format, URI ist die Bezeichnung von Resourcen von Webservices
                    // Hier benutzt um die Invoice zu downloaden.
                    .uri(URI.create(String.format("http://localhost:8080/invoices/%s", id)))
                    .GET()
                    .build();

            try {
                //Client soll nun eine Response triggern, welche als UTF-8 String retourniert wird.
                HttpResponse<String> response = client.send(getRequest, HttpResponse.BodyHandlers.ofString());

                //Retourn-Code vom Request
                int statusCode = response.statusCode();
                //200 -> OK, 201 -> Created, 202-> Accepted usw. https://de.wikipedia.org/wiki/HTTP-Statuscode
                if (statusCode >= 200 && statusCode < 300) {
                    String responseBody = response.body();
                    //Ausgabe des Response Bodies, falls der Statuscode passt.
                    Platform.runLater(() -> responseCreationInvoice.setText(responseBody));
                    responseCreationInvoice.setVisible(true);
                    try {
                        // Suche des pdfs im Filestorage mit der richtigen ID
                        File file = new File(".\\Backend-Services\\FileStorage\\"+id+".pdf");
                        HostServices hostServices = getHostServices();
                        hostServices.showDocument(file.getAbsolutePath());
                        //Ausgabe des Files im Web-Browser
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    System.err.println();
                    // Ausgabe Statuscode, falls dieser nicht zwischen 200 und 300 liegt.
                    // Error 404 -> Not Found: Resource wurde nicht gefunden https://de.wikipedia.org/wiki/HTTP-Statuscode
                    responseCreationInvoice.setText("HTTP Error: " + statusCode);
                    responseCreationInvoice.setVisible(true);

                }
            } catch (Exception e) {
                // Dieses Errorhandling benützt einen Stack, wo falls das Catch aufgerufen
                // wird alle Errors in diesem Try geprinted werden.
                e.printStackTrace();
            }

        } else if (id.isEmpty()) {
            // Falls das Eingabefeld leer ist.
            responseCreationInvoice.setText("The field is empty");
            responseCreationInvoice.setVisible(true);

        } else {
            //Falls Buchstaben mitgegeben werden.
            responseCreationInvoice.setText("The field should only contain numbers");
            responseCreationInvoice.setVisible(true);

        }
    }

    @Override
    public void start(Stage stage) throws Exception {
        // Muss wegen Application eingefügt sein.
    }
}