package com.example.javafxapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

// Die Klasse HelloApplication startet eine JavaFX-Anwendung.
public class HelloApplication extends Application {
    @Override // @Override wird verwendet, um eine Methode der Superklasse zu überschreiben.
    public void start(Stage stage) throws IOException {
        // Lädt das FXML-Dokument hello-view.fxml (in com.example.javafxapp) zur Darstellung der JavaFX-GUI
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 300); // Erstellt eine neue Szene mit der geladenen FXML-Datei und den Abmessungen 500x300
        stage.setScene(scene); // Setzt die Szene auf die Bühne
        stage.show(); // Zeigt die Bühne an
    }

    public static void main(String[] args) {
        // Startet die JavaFX-Anwendung
        launch();
    }
}
