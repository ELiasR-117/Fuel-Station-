package com.example.javafxapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class HelloApplication extends Application {
    @Override //Override wird für die Überschreibung einer Superklassenmethode verwendet.
    public void start(Stage stage) throws IOException {
        // Aufruf der des FXML hello-view.fxml (In com.example.javafxapp) zur Ausgabe der FX-GUI
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 300);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        // Start des GUIs
        launch();
    }
}