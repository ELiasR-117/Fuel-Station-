package org.example;

import org.example.Data.Station;
import org.example.Service.Database;
import org.example.Service.Queue;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeoutException;

// Die Main-Klasse dient als Einstiegspunkt für die Anwendung.
public class Main {
    // Die main-Methode ist der Einstiegspunkt der Anwendung.
    public static void main(String[] args) throws IOException, TimeoutException {
        // Initialisiert eine Instanz der Database-Klasse.
        Database db = new Database();

        // Initialisiert eine Instanz der Queue-Klasse.
        Queue queue = new Queue();

        // Erstellt eine Instanz des DataCollectionDispatcher mit den Database- und Queue-Objekten.
        DataCollectionDispatcher dcd = new DataCollectionDispatcher(db, queue);

        // Ruft die getDatabase-Methode des DataCollectionDispatcher auf, um eine Liste von Stationen aus der Datenbank abzurufen.
        List<Station> stations = dcd.getDatabase();

        // Ruft die wait-Methode des DataCollectionDispatcher auf, um Nachrichten in der Warteschlange zu empfangen und die Stationen zu verarbeiten.
        dcd.wait(stations);
    }
}
