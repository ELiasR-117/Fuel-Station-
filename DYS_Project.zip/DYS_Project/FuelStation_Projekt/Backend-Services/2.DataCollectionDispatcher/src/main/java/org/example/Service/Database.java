package org.example.Service;

import org.example.Data.Station;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// Die Klasse Database stellt Methoden zur Verbindung mit der Datenbank und zum Abrufen von Stationen bereit.
public class Database {
    // Konstanten zur Konfiguration der Datenbankverbindung
    private final static String DRIVER = "postgresql"; // Der verwendete Datenbanktreiber
    private final static String HOST = "localhost"; // Der Hostname des Datenbankservers
    private final static int PORT = 30002; // Der Port des Datenbankservers
    private final static String DATABASE_NAME = "stationdb"; // Der Name der Datenbank
    private final static String USERNAME = "user"; // Der Benutzername für die Datenbankverbindung
    private final static String PASSWORD = "password"; // Das Passwort für die Datenbankverbindung

    // Methode zur Erstellung einer Verbindung zur Datenbank
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(getUrl()); // Verbindet sich mit der Datenbank unter Verwendung der generierten URL
    }

    // Methode zum Abrufen aller Stationen aus der Datenbank
    public static List<Station> select() {
        String query = "SELECT * FROM station"; // SQL-Abfrage zum Abrufen aller Stationen

        List<Station> stations = new ArrayList<>(); // Liste zur Speicherung der abgerufenen Stationen
        try (
                Connection conn = Database.getConnection(); // Verbindung zur Datenbank herstellen
                PreparedStatement ps = conn.prepareStatement(query); // Vorbereitung der SQL-Abfrage
                ResultSet rs = ps.executeQuery() // Ausführung der Abfrage und Speicherung der Ergebnisse im ResultSet
        ) {
            while(rs.next()) { // Schleife zum Durchlaufen der Abfrageergebnisse
                int id = rs.getInt("id"); // Abrufen der ID der Station
                String db_url = rs.getString("db_url"); // Abrufen der Datenbank-URL der Station
                float lat = rs.getFloat("lat"); // Abrufen des Breitengrads der Station
                float lng = rs.getFloat("lng"); // Abrufen des Längengrads der Station

                Station station = new Station(id, db_url, lat, lng); // Erstellung eines Station-Objekts
                stations.add(station); // Hinzufügen der Station zur Liste

                System.out.printf(station.toString()); // Ausgabe der Station zur Konsole
            }
        } catch (SQLException e) { // Fehlerbehandlung bei SQL-Ausnahmen
            System.out.println(e.getMessage()); // Ausgabe der Fehlermeldung zur Konsole
        }
        return stations; // Rückgabe der Liste der Stationen
    }

    // Methode zur Erstellung der URL für die Datenbankverbindung
    private static String getUrl() {
        // jdbc:DRIVER://HOST:PORT/DATABASE_NAME?username=USERNAME?password=PASSWORD
        return String.format(
                "jdbc:%s://%s:%s/%s?user=%s&password=%s", DRIVER, HOST, PORT, DATABASE_NAME, USERNAME, PASSWORD
        ); // Formatieren der Verbindungs-URL mit den Konfigurationskonstanten
    }
}
