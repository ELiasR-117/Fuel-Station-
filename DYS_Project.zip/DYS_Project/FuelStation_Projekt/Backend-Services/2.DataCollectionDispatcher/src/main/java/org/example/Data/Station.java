package org.example.Data;

// Die Klasse Station repräsentiert eine Station mit einer ID, einer Datenbank-URL, Breitengrad und Längengrad.
public class Station {

    // Private Felder zur Speicherung der Eigenschaften der Station
    private int id = 0;           // Eindeutige Kennung der Station
    private String db_url = null; // URL der zugehörigen Datenbank
    private float lat;            // Breitengrad der Station
    private float lng;            // Längengrad der Station

    // Konstruktor zur Initialisierung der Station-Objekte mit den angegebenen Werten
    public Station(int id, String db_url, float lat, float lng) {
        this.id = id;            // Setzt die ID der Station
        this.db_url = db_url;    // Setzt die Datenbank-URL der Station
        this.lat = lat;          // Setzt den Breitengrad der Station
        this.lng = lng;          // Setzt den Längengrad der Station
    }

    // Getter-Methode zur Rückgabe der ID der Station
    public int getId() {
        return id;
    }

    // Setter-Methode zur Änderung der ID der Station
    public void setId(int id) {
        this.id = id;
    }

    // Getter-Methode zur Rückgabe der Datenbank-URL der Station
    public String getUrl() {
        return db_url;
    }

    // Setter-Methode zur Änderung der Datenbank-URL der Station
    public void setUrl(String db_url) {
        this.db_url = db_url;
    }

    // Getter-Methode zur Rückgabe des Breitengrads der Station
    public float getLat() {
        return lat;
    }

    // Setter-Methode zur Änderung des Breitengrads der Station
    public void setLat(float lat) {
        this.lat = lat;
    }

    // Getter-Methode zur Rückgabe des Längengrads der Station
    public float getLng() {
        return lng;
    }

    // Setter-Methode zur Änderung des Längengrads der Station
    public void setLng(float lng) {
        this.lng = lng;
    }

    // Überschriebene toString-Methode zur Rückgabe einer String-Repräsentation der Station
    @Override
    public String toString() {
        return "Station{id='" + id + "', db_url='" + db_url + "', lat='" + lat + "', lng='" + lng + "'}\n";
    }
}
