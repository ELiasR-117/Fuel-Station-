package org.example;

import org.example.Data.Station;
import org.example.Service.Database;
import org.example.Service.Queue;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

// Die Klasse DataCollectionDispatcher koordiniert die Datenbank- und Warteschlangenoperationen.
public class DataCollectionDispatcher {

    // Private Felder zur Speicherung der Instanzen von Database und Queue
    private final Database database;
    private final Queue queue;

    // Konstruktor zur Initialisierung der DataCollectionDispatcher-Instanz mit Database- und Queue-Objekten
    public DataCollectionDispatcher(Database database, Queue queue) {
        this.database = database; // Initialisiert das Datenbank-Objekt
        this.queue = queue; // Initialisiert das Warteschlangen-Objekt
    }

    // Methode zum Abrufen der Stationen aus der Datenbank
    public List<Station> getDatabase() {
        return Database.select(); // Ruft die select-Methode der Database-Klasse auf, um alle Stationen abzurufen
    }

    // Methode zum Warten auf Nachrichten in der Warteschlange und zur Verarbeitung der Stationen
    public void wait(List<Station> stations) throws IOException, TimeoutException {
        this.queue.receive(stations); // Ruft die receive-Methode der Queue-Klasse auf, um Nachrichten zu empfangen und Stationen zu verarbeiten
    }
}
