package org.example.Service;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import org.example.Data.Station;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.List;
import java.util.concurrent.TimeoutException;

// Die Klasse Queue stellt Methoden zur Kommunikation mit RabbitMQ-Warteschlangen bereit.
public class Queue {

    // Konstanten zur Konfiguration der RabbitMQ-Warteschlangen und Verbindungsparameter
    private final static String CONSUME = "SA_DCD"; // Warteschlange zum Empfangen von Nachrichten
    private final static String PRODUCE1 = "DCD_SDC"; // Warteschlange zum Senden von Nachrichten an Station Data Collector
    private final static String PRODUCE2 = "DCD_DCR"; // Warteschlange zum Informieren des Data Collection Receivers
    private final static String HOST = "localhost"; // Hostname des RabbitMQ-Servers
    private final static int PORT = 30003; // Port des RabbitMQ-Servers

    private int id; // Variable zur Speicherung einer empfangenen ID
    private static ConnectionFactory factory; // Factory zur Erstellung von Verbindungen zu RabbitMQ

    // Konstruktor zur Initialisierung der ConnectionFactory mit Host und Port
    public Queue() {
        factory = new ConnectionFactory();
        factory.setHost(HOST);
        factory.setPort(PORT);
    }

    // Methode zum Empfangen von Nachrichten aus der RabbitMQ-Warteschlange
    public void receive(List<Station> stations) throws IOException, TimeoutException {
        Connection connection = factory.newConnection(); // Verbindung zu RabbitMQ herstellen
        Channel channel = connection.createChannel(); // Kanal erstellen

        channel.queueDeclare(CONSUME, false, false, false, null); // Warteschlange deklarieren
        System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

        // Callback-Funktion zum Verarbeiten empfangener Nachrichten
        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8); // Nachricht lesen
            System.out.println(" [x] Received '" + message + "' " + LocalTime.now());
            this.id = Integer.parseInt(message); // Nachricht in eine ID umwandeln

            try {
                send(stations); // Nachrichten weiterleiten
            } catch (TimeoutException e) {
                throw new RuntimeException(e); // Fehlerbehandlung
            }
        };

        channel.basicConsume(CONSUME, true, deliverCallback, consumerTag -> {}); // Nachrichten konsumieren
    }

    // Methode zum Senden von Nachrichten an die RabbitMQ-Warteschlange
    private void send(List<Station> stations) throws IOException, TimeoutException {
        int i = 0;
        try (
                Connection connection = factory.newConnection(); // Verbindung zu RabbitMQ herstellen
                Channel channel = connection.createChannel() // Kanal erstellen
        ) {
            channel.queueDeclare(PRODUCE1, false, false, false, null); // Warteschlange deklarieren
            for (Station s : stations) { // Für jede Station eine Nachricht senden
                String message = "db_url=" + s.getUrl() + "&id=" + this.id;
                channel.basicPublish("", PRODUCE1, null, message.getBytes(StandardCharsets.UTF_8)); // Nachricht senden

                i++;
                System.out.println(" [" + i + "] sent '" + this.id + "' to Station Data Collector");
            }
        }
        inform(i); // Data Collection Receiver informieren
    }

    // Methode zum Informieren des Data Collection Receivers über die Anzahl der gesendeten Nachrichten
    private void inform(int i) throws IOException, TimeoutException {
        try (
                Connection connection = factory.newConnection(); // Verbindung zu RabbitMQ herstellen
                Channel channel = connection.createChannel() // Kanal erstellen
        ) {
            channel.queueDeclare(PRODUCE2, false, false, false, null); // Warteschlange deklarieren

            String message = "count=" + i + "&id=" + this.id; // Nachricht erstellen
            channel.basicPublish("", PRODUCE2, null, message.getBytes(StandardCharsets.UTF_8)); // Nachricht senden
            System.out.println(" [x" + i + "] informed Data Collection Receiver about ID " + id);
        }
    }
}
