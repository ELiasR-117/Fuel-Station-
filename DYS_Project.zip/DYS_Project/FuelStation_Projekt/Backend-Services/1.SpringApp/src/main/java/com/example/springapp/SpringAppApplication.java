package com.example.springapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Die Klasse SpringAppApplication ist der Einstiegspunkt der Spring Boot-Anwendung.
@SpringBootApplication // Annotation zur Kennzeichnung als Spring Boot-Anwendung
public class SpringAppApplication {

	// Die main-Methode ist der Einstiegspunkt der Anwendung.
	public static void main(String[] args) {
		// Startet die Spring Boot-Anwendung.
		SpringApplication.run(SpringAppApplication.class, args);
	}
}
