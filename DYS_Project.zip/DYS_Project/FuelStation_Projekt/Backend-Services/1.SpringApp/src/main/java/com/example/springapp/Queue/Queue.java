package com.example.springapp.Queue;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

// Die Klasse Queue stellt eine Methode zum Senden von Nachrichten an eine RabbitMQ-Warteschlange bereit.
public class Queue {
    // Konstanten zur Konfiguration der RabbitMQ-Warteschlange und Verbindungsparameter
    private final static String QUEUE_NAME = "SA_DCD"; // Name der Warteschlange
    private final static String HOST = "localhost"; // Hostname des RabbitMQ-Servers
    private final static Integer PORT = 30003; // Port des RabbitMQ-Servers

    // Methode zum Senden einer Nachricht an die RabbitMQ-Warteschlange
    public boolean send(String id) {
        boolean messageSent = false; // Variable zur Verfolgung, ob die Nachricht gesendet wurde
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost(HOST);
        factory.setPort(PORT);
        try (Connection connection = factory.newConnection();
             Channel channel = connection.createChannel()) {
            channel.queueDeclare(QUEUE_NAME, false, false, false, null); // Warteschlange deklarieren
            channel.basicPublish("", QUEUE_NAME, null, id.getBytes()); // Nachricht senden
            System.out.println(" [x] Sent '" + id + "'"); // Bestätigungsmeldung ausgeben
            messageSent = true; // Erfolgsstatus setzen
        } catch (IOException | TimeoutException e) {
            // Fehlerbehandlung: Druckt den Stack-Trace, falls eine Ausnahme auftritt
            e.printStackTrace();
        }
        return messageSent; // Rückgabe, ob die Nachricht gesendet wurde
    }
}
