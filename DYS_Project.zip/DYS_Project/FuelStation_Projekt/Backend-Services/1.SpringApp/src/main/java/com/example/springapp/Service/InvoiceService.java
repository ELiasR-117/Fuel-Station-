package com.example.springapp.Service;

import com.example.springapp.Queue.Queue;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

// Die Klasse InvoiceService bietet Dienste zur Erstellung und zum Abrufen von Rechnungen.
@Service
public class InvoiceService {
    // Erstellung einer neuen Queue-Instanz
    private final Queue queue = new Queue();

    // Methode zur Erstellung einer Rechnung für eine gegebene Kunden-ID
    public boolean createInvoice(String customerID) {
        return queue.send(customerID); // Senden der Kunden-ID an die Warteschlange
    }

    // Methode zum Abrufen einer Rechnung für eine gegebene Kunden-ID
    public List<String> getInvoice(int customerID) {
        // Pfad zum Speicherort der PDF-Dateien
        String fileStoragePath = "FuelStation_Projekt/Backend-Services/FileStorage/invoice_";
        String filePath = fileStoragePath + customerID + ".pdf";
        Path path = Paths.get(filePath);

        // Überprüfung, ob die Datei existiert und eine reguläre Datei ist
        if (Files.exists(path) && Files.isRegularFile(path)) {
            List<String> invoiceInfo = new ArrayList<>();
            invoiceInfo.add(filePath); // Hinzufügen des Dateipfads zur Liste

            try {
                // Abrufen und Formatieren der Erstellungszeit der Datei
                FileTime creationTime = Files.getLastModifiedTime(path);
                String formattedCreationTime = creationTime.toInstant()
                        .atZone(ZoneId.systemDefault())
                        .format(DateTimeFormatter.ofPattern("dd.MM.yyyy - HH:mm"));
                invoiceInfo.add("Created On: " + formattedCreationTime); // Hinzufügen der Erstellungszeit zur Liste
            } catch (IOException e) {
                e.printStackTrace(); // Fehlerbehandlung
            }
            return invoiceInfo; // Rückgabe der Rechnungsinformationen
        }
        return null; // Rückgabe null, wenn die Datei nicht existiert oder keine reguläre Datei ist
    }
}
