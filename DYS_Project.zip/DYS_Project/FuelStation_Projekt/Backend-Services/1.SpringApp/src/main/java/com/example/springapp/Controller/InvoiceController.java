package com.example.springapp.Controller;

import com.example.springapp.Service.InvoiceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Die Klasse InvoiceController stellt REST-Endpoints für Rechnungen bereit.
@RestController
public class InvoiceController {
    private final InvoiceService invSer; // Service zur Verarbeitung von Rechnungen

    // Konstruktor zur Initialisierung des InvoiceController mit einem InvoiceService
    public InvoiceController(InvoiceService invService) {
        this.invSer = invService;
    }

    // POST-Endpoint zum Erstellen einer Rechnung für einen Kunden
    @PostMapping("/invoices/{customerID}")
    public ResponseEntity<String> gatherData(@PathVariable String customerID) {
        boolean requestSent = invSer.createInvoice(customerID); // Aufruf des Services zur Erstellung der Rechnung
        if (requestSent) {
            return new ResponseEntity<>("Request to gather data sent!", HttpStatus.OK); // Erfolgreiche Antwort
        }
        return new ResponseEntity<>("Request to gather data could not be sent!", HttpStatus.INTERNAL_SERVER_ERROR); // Fehlerantwort
    }

    // GET-Endpoint zum Abrufen einer Rechnung für einen Kunden
    @GetMapping("/invoices/{customerID}")
    public ResponseEntity<List<String>> gatherInvoice(@PathVariable String customerID) {
        List<String> invoiceInfo = invSer.getInvoice(Integer.parseInt(customerID)); // Aufruf des Services zum Abrufen der Rechnung
        if (invoiceInfo != null) {
            return new ResponseEntity<>(invoiceInfo, HttpStatus.OK); // Erfolgreiche Antwort mit Rechnungsdaten
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Antwort, wenn keine Rechnung gefunden wurde
    }
}
