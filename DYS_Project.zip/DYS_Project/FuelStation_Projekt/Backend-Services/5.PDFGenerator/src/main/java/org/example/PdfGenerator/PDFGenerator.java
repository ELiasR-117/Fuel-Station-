package org.example.PdfGenerator;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.example.Data.Customer;
import org.example.Service.Queue;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.concurrent.TimeoutException;

// Die Klasse PDFGenerator erzeugt PDF-Dokumente basierend auf erhaltenen Daten.
public class PDFGenerator {

    // Die main-Methode ist der Einstiegspunkt der Anwendung.
    public static void main(String[] args) {
        Queue queue = new Queue(); // Erstellt eine Instanz der Queue-Klasse.
        listen(queue); // Ruft die listen-Methode auf, um auf Nachrichten in der Warteschlange zu warten.
    }

    // Methode zum Warten auf Nachrichten in der Warteschlange.
    private static void listen(Queue queue) {
        try {
            queue.receive(); // Ruft die receive-Methode der Queue-Instanz auf.
        } catch (IOException | TimeoutException e) {
            throw new RuntimeException(e); // Fehlerbehandlung
        }
    }

    // Methode zum Erzeugen eines PDF-Dokuments.
    public static void generate(float kwh, Customer customer) {
        System.out.println("Generating PDF...");

        PDDocument doc = new PDDocument(); // Erstellt ein neues PDF-Dokument.
        PDPage firstPage = new PDPage(); // Erstellt eine neue Seite.
        doc.addPage(firstPage); // Fügt die Seite zum Dokument hinzu.

        int pagingHeight = (int) firstPage.getTrimBox().getHeight(); // Höhe der Seite.
        PDFont font = PDType1Font.HELVETICA_BOLD; // Schriftart für den Text.

        try {
            PDPageContentStream contentStream = new PDPageContentStream(doc, firstPage); // Erstellt einen Content-Stream für die Seite.
            contentStream.beginText(); // Startet den Textmodus.
            contentStream.setLeading(16.0f); // Zeilenabstand setzen.
            contentStream.newLineAtOffset(50, pagingHeight-50); // Startposition des Textes.

            contentStream.setFont(font, 20);
            contentStream.showText("Receipt"); // Text hinzufügen.
            contentStream.newLine();
            contentStream.newLine();

            contentStream.setFont(font, 16);
            contentStream.showText("Created on: " + date()); // Erstellungsdatum hinzufügen.
            contentStream.newLine();
            contentStream.newLine();

            contentStream.setFont(font, 12);
            contentStream.showText("Customer Details"); // Kundendetails hinzufügen.
            contentStream.newLine();
            contentStream.showText("Name: " + customer.getFirstName() + " " + customer.getLastName());
            contentStream.newLine();
            contentStream.showText("ID.: " + customer.getId());
            contentStream.newLine();
            contentStream.newLine();
            contentStream.newLine();

            contentStream.setFont(font, 16);
            contentStream.showText("Charge details"); // Ladungsdetails hinzufügen.
            contentStream.newLine();
            contentStream.newLine();

            contentStream.setFont(font, 12);
            contentStream.showText(String.format("Total charges: %.2f kwH", kwh)); // Gesamtkosten hinzufügen.
            contentStream.newLine();
            contentStream.showText(String.format("Total price: %.2f €", kwh * 0.5)); // Gesamtpreis hinzufügen.

            contentStream.endText(); // Textmodus beenden.
            contentStream.close(); // Content-Stream schließen.

            doc.save("FuelStation_Projekt/Backend-Services/FileStorage/invoice_" + customer.getId() + ".pdf"); // PDF-Dokument speichern.
            doc.close(); // Dokument schließen.
            System.out.println("PDF was created!"); // Erfolgsmeldung ausgeben.
        } catch (IOException e) {
            throw new RuntimeException(e); // Fehlerbehandlung.
        }
    }

    // Methode zur Erstellung des aktuellen Datums als String.
    private static String date() {
        return String.format(
                "%s %02d, %04d (%02d:%02d:%02d)",
                LocalDate.now().getMonth().getDisplayName(TextStyle.FULL, Locale.US), // Monat
                LocalDate.now().getDayOfMonth(), // Tag
                LocalDate.now().getYear(), // Jahr
                LocalTime.now().getHour(), // Stunde
                LocalTime.now().getMinute(), // Minute
                LocalTime.now().getSecond()); // Sekunde
    }
}
