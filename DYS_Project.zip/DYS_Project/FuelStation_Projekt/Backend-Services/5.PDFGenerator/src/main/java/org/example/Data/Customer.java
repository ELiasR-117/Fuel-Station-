package org.example.Data;

// Die Klasse Customer repräsentiert einen Kunden mit einer ID, einem Vornamen und einem Nachnamen.
public class Customer {
    // Statische Felder zur Speicherung der Eigenschaften eines Kunden
    private static int id = 0;           // Eindeutige Kennung des Kunden
    private static String firstName = null; // Vorname des Kunden
    private static String lastName = null;  // Nachname des Kunden

    // Konstruktor zur Initialisierung eines Customer-Objekts mit den angegebenen Werten
    public Customer(int id, String firstName, String lastName) {
        setId(id);             // Setzt die ID des Kunden
        setFirstName(firstName); // Setzt den Vornamen des Kunden
        setLastName(lastName);   // Setzt den Nachnamen des Kunden
    }

    // Getter-Methode zur Rückgabe der ID des Kunden
    public int getId() {
        return id;
    }

    // Setter-Methode zur Änderung der ID des Kunden
    public void setId(int id) {
        this.id = id;
    }

    // Getter-Methode zur Rückgabe des Vornamens des Kunden
    public String getFirstName() {
        return firstName;
    }

    // Setter-Methode zur Änderung des Vornamens des Kunden
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Getter-Methode zur Rückgabe des Nachnamens des Kunden
    public String getLastName() {
        return lastName;
    }

    // Setter-Methode zur Änderung des Nachnamens des Kunden
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Überschriebene toString-Methode zur Rückgabe einer String-Repräsentation des Kunden
    @Override
    public String toString() {
        return "User{id='" + id + "', firstName='" + firstName + "', lastName='" + lastName + "'}\n";
    }
}
