package org.example.Service;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import org.example.PdfGenerator.PDFGenerator;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.concurrent.TimeoutException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Die Klasse Queue stellt Methoden zur Kommunikation mit einer RabbitMQ-Warteschlange bereit.
public class Queue {

    // Konstanten zur Konfiguration der RabbitMQ-Warteschlange und Verbindungsparameter
    private final static String CONSUME = "DCR_PG"; // Warteschlange zum Empfangen von Nachrichten
    private final static String HOST = "localhost"; // Hostname des RabbitMQ-Servers
    private final static int PORT = 30003; // Port des RabbitMQ-Servers

    private float kwh; // Variable zur Speicherung der geladenen kWh
    private int id; // Variable zur Speicherung der Kunden-ID

    private static ConnectionFactory factory; // Factory zur Erstellung von Verbindungen zu RabbitMQ

    // Konstruktor zur Initialisierung der ConnectionFactory mit Host und Port
    public Queue() {
        factory = new ConnectionFactory();
        factory.setHost(HOST);
        factory.setPort(PORT);
    }

    // Methode zum Empfangen von Nachrichten aus der RabbitMQ-Warteschlange
    public void receive() throws IOException, TimeoutException {
        Connection connection = factory.newConnection(); // Verbindung zu RabbitMQ herstellen
        Channel channel = connection.createChannel(); // Kanal erstellen

        channel.queueDeclare(CONSUME, false, false, false, null); // Warteschlange deklarieren
        System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

        // Callback-Funktion zum Verarbeiten empfangener Nachrichten
        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8); // Nachricht lesen
            System.out.println(" [x] Received '" + message + "' " + LocalTime.now());

            // Regex-Muster zur Extraktion der ID und der geladenen kWh aus der Nachricht
            String pattern = "id=(\\d+)&totalKWH=(\\d.+)";
            Pattern regex = Pattern.compile(pattern);
            Matcher matcher = regex.matcher(message);

            // Überprüfung, ob die Nachricht das Muster enthält
            if (matcher.find()) {
                id = Integer.parseInt(matcher.group(1)); // Extrahieren und Setzen der ID
                kwh = Float.parseFloat(matcher.group(2)); // Extrahieren und Setzen der geladenen kWh
                System.out.println("Extracted id: " + id);
                System.out.println("Extracted kwh: " + kwh);
            } else {
                System.out.println("Numbers not found."); // Fehlermeldung, falls das Muster nicht gefunden wird
            }

            // Überprüfung, ob kWh geladen wurden
            if(kwh != 0.0)
                // Falls kWh geladen wurden, wird ein PDF generiert
                PDFGenerator.generate(getKwh(), Database.select(getId()));
            else
                // Fehlerausgabe, falls keine kWh geladen wurden
                System.out.println("Customer on this ID ("+id+") did not charge or does not exist yet!");
        };

        channel.basicConsume(CONSUME, true, deliverCallback, consumerTag -> {}); // Nachrichten konsumieren
    }

    // Getter-Methode zur Rückgabe der geladenen kWh
    public float getKwh() {
        return kwh;
    }

    // Getter-Methode zur Rückgabe der Kunden-ID
    public int getId() {
        return id;
    }
}
