package org.example.Service;

import org.example.Data.Customer;

import java.sql.*;

// Die Klasse Database stellt Methoden zur Verbindung mit der Datenbank und zum Abrufen von Kundendaten bereit.
public class Database {
    // Konstanten zur Konfiguration der Datenbankverbindung
    private final static String DRIVER = "postgresql"; // Der verwendete Datenbanktreiber
    private final static String HOST = "localhost"; // Der Hostname des Datenbankservers
    private final static int PORT = 30001; // Der Port des Datenbankservers
    private final static String DATABASE_NAME = "customerdb"; // Der Name der Datenbank
    private final static String USERNAME = "user"; // Der Benutzername für die Datenbankverbindung
    private final static String PASSWORD = "password"; // Das Passwort für die Datenbankverbindung

    // Methode zur Erstellung einer Verbindung zur Datenbank
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(getUrl()); // Verbindet sich mit der Datenbank unter Verwendung der generierten URL
    }

    // Methode zum Abrufen eines Kunden aus der Datenbank anhand der Kunden-ID
    public static Customer select(int sid) {
        // SQL-Abfrage, um den Datensatz des Kunden zu erhalten
        String query = "SELECT * FROM customer WHERE id = ?;";

        Customer customer = null; // Variable zur Speicherung des Kundenobjekts
        try (
                Connection conn = Database.getConnection(); // Verbindung zur Datenbank herstellen
                PreparedStatement ps = conn.prepareStatement(query) // Vorbereitung der SQL-Abfrage
        ) {
            // Setzt den Parameterwert auf die übergebene Kunden-ID
            ps.setInt(1, sid);
            try (
                    ResultSet rs = ps.executeQuery() // Ausführung der Abfrage und Speicherung der Ergebnisse im ResultSet
            ) {
                // Schleife über die gefundenen Datensätze
                while(rs.next()) {
                    int id = rs.getInt("id"); // Abrufen der ID des Kunden
                    String firstName = rs.getString("first_name"); // Abrufen des Vornamens des Kunden
                    String lastName = rs.getString("last_name"); // Abrufen des Nachnamens des Kunden

                    // Überprüfung, ob keine der Felder leer ist
                    if (id != 0 && !firstName.isEmpty() && !lastName.isEmpty()) {
                        customer = new Customer(id, firstName, lastName); // Erstellung eines Customer-Objekts
                    }

                    System.out.printf(customer.toString()); // Ausgabe des Kundenobjekts zur Konsole
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage()); // Fehlerbehandlung bei SQL-Ausnahmen
            }
            return customer; // Rückgabe des Kundenobjekts
        } catch (SQLException e) {
            throw new RuntimeException(e); // Fehlerbehandlung bei SQL-Ausnahmen
        }
    }

    // Methode zur Erstellung der URL für die Datenbankverbindung
    private static String getUrl() {
        // jdbc:DRIVER://HOST:PORT/DATABASE_NAME?username=USERNAME?password=PASSWORD
        return String.format("jdbc:%s://%s:%s/%s?user=%s&password=%s", DRIVER, HOST, PORT, DATABASE_NAME, USERNAME, PASSWORD); // Formatieren der Verbindungs-URL mit den Konfigurationskonstanten
    }
}
