package org.example;

import org.example.Service.Queue;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

// Die Main-Klasse dient als Einstiegspunkt für die Anwendung.
public class Main {
    // Die main-Methode ist der Einstiegspunkt der Anwendung.
    public static void main(String[] args) throws IOException, TimeoutException {
        // Erstellt eine Instanz der Queue-Klasse.
        Queue q1 = new Queue();

        // Ruft die receive-Methode der Queue-Instanz auf, um Nachrichten aus der RabbitMQ-Warteschlange zu empfangen.
        q1.receive();
    }
}
