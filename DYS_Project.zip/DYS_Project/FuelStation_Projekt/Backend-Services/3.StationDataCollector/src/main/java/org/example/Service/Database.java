package org.example.Service;

import java.sql.*;

// Die Klasse Database stellt Methoden zur Verbindung mit der Datenbank und zum Abrufen von Daten bereit.
public class Database {

    // Konstanten zur Konfiguration der Datenbankverbindung
    private final static String DRIVER = "postgresql"; // Der verwendete Datenbanktreiber
    private final static String HOST = "localhost"; // Der Hostname des Datenbankservers
    private static int PORT; // Der Port des Datenbankservers (wird durch den Konstruktor gesetzt)
    private final static String DATABASE_NAME = "stationdb"; // Der Name der Datenbank
    private final static String USERNAME = "user"; // Der Benutzername für die Datenbankverbindung
    private final static String PASSWORD = "password"; // Das Passwort für die Datenbankverbindung

    // Konstruktor zur Initialisierung der Database-Instanz mit dem Port
    public Database(int port) {
        this.PORT = port; // Setzt den Port für die Datenbankverbindung
    }

    // Methode zur Erstellung einer Verbindung zur Datenbank
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(getUrl()); // Verbindet sich mit der Datenbank unter Verwendung der generierten URL
    }

    // Methode zum Abrufen der Gesamtsumme der kWh für eine bestimmte Kunden-ID
    public float select(int cid) {
        String query = "SELECT kwh FROM charge WHERE customer_id = ?"; // SQL-Abfrage zum Abrufen der kWh-Werte für eine bestimmte Kunden-ID
        float kwh = 0; // Variable zur Speicherung der Gesamtsumme der kWh

        try (
                Connection conn = Database.getConnection(); // Verbindung zur Datenbank herstellen
                PreparedStatement ps = conn.prepareStatement(query); // Vorbereitung der SQL-Abfrage
        ) {
            ps.setInt(1, cid); // Setzt die Kunden-ID als Parameter in der Abfrage

            try (ResultSet rs = ps.executeQuery()) { // Ausführung der Abfrage und Speicherung der Ergebnisse im ResultSet
                while (rs.next()) { // Schleife zum Durchlaufen der Abfrageergebnisse
                    kwh += rs.getFloat("kwh"); // Hinzufügen des kWh-Werts zur Gesamtsumme
                }
            }
        } catch (SQLException e) { // Fehlerbehandlung bei SQL-Ausnahmen
            System.out.println(e.getMessage()); // Ausgabe der Fehlermeldung zur Konsole
        }
        return kwh; // Rückgabe der Gesamtsumme der kWh
    }

    // Methode zur Erstellung der URL für die Datenbankverbindung
    private static String getUrl() {
        // jdbc:DRIVER://HOST:PORT/DATABASE_NAME?username=USERNAME?password=PASSWORD
        return String.format(
                "jdbc:%s://%s:%s/%s?user=%s&password=%s", DRIVER, HOST, PORT, DATABASE_NAME, USERNAME, PASSWORD
        ); // Formatieren der Verbindungs-URL mit den Konfigurationskonstanten
    }
}
