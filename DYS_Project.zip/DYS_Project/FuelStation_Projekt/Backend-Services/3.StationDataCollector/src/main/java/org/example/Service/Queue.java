package org.example.Service;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.concurrent.TimeoutException;

// Die Klasse Queue stellt Methoden zur Kommunikation mit RabbitMQ-Warteschlangen bereit.
public class Queue {

    // Konstanten zur Konfiguration der RabbitMQ-Warteschlangen und Verbindungsparameter
    private final static String CONSUME = "DCD_SDC"; // Warteschlange zum Empfangen von Nachrichten
    private final static String PRODUCE = "SDC_DCR"; // Warteschlange zum Senden von Nachrichten an Data Collection Receiver

    private final static String HOST = "localhost"; // Hostname des RabbitMQ-Servers
    private final static int PORT = 30003; // Port des RabbitMQ-Servers

    private int id; // Variable zur Speicherung einer empfangenen ID

    private static ConnectionFactory factory; // Factory zur Erstellung von Verbindungen zu RabbitMQ

    // Konstruktor zur Initialisierung der ConnectionFactory mit Host und Port
    public Queue() {
        factory = new ConnectionFactory();
        factory.setHost(HOST);
        factory.setPort(PORT);
    }

    // Methode zum Empfangen von Nachrichten aus der RabbitMQ-Warteschlange
    public void receive() throws IOException, TimeoutException {
        Connection connection = factory.newConnection(); // Verbindung zu RabbitMQ herstellen
        Channel channel = connection.createChannel(); // Kanal erstellen

        channel.queueDeclare(CONSUME, false, false, false, null); // Warteschlange deklarieren
        System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

        // Callback-Funktion zum Verarbeiten empfangener Nachrichten
        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8); // Nachricht lesen
            System.out.println(" [x] Received '" + message + "' " + LocalTime.now());

            float kwh = getKWH(message); // kWh-Wert aus der Nachricht abrufen
            try {
                send(kwh); // Nachricht weiterleiten
            } catch (TimeoutException e) {
                throw new RuntimeException(e); // Fehlerbehandlung
            }
        };

        channel.basicConsume(CONSUME, true, deliverCallback, consumerTag -> {}); // Nachrichten konsumieren
    }

    // Methode zum Senden von Nachrichten an die RabbitMQ-Warteschlange
    private void send(float kwh) throws IOException, TimeoutException {
        try (
                Connection connection = factory.newConnection(); // Verbindung zu RabbitMQ herstellen
                Channel channel = connection.createChannel() // Kanal erstellen
        ) {
            channel.queueDeclare(PRODUCE, false, false, false, null); // Warteschlange deklarieren
            String message = String.format("id=%s&kwh=%.1f", id, kwh); // Nachricht erstellen
            channel.basicPublish("", PRODUCE, null, message.getBytes(StandardCharsets.UTF_8)); // Nachricht senden
            System.out.println(message); // Nachricht zur Konsole ausgeben
        }
    }

    // Methode zum Abrufen des kWh-Werts aus der Nachricht
    public float getKWH(String message) {
        String[] parts = message.split("db_url=localhost:|&id="); // Nachricht in Teile splitten
        int port = Integer.parseInt(parts[1]); // Port aus der Nachricht extrahieren
        this.id = Integer.parseInt(parts[2]); // ID aus der Nachricht extrahieren
        Database db = new Database(port); // Database-Objekt mit dem extrahierten Port erstellen
        return db.select(id); // kWh-Wert aus der Datenbank abrufen und zurückgeben
    }
}
