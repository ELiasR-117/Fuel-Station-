CREATE DATABASE customerdb;
\c customerdb;

CREATE TABLE IF NOT EXISTS customer (
   id serial PRIMARY KEY,
   first_name VARCHAR(255) NOT NULL,
   last_name VARCHAR(255) NOT NULL
);

INSERT INTO customer(id, first_name, last_name)
VALUES 
   (1, 'Luisa', 'Colin'),
	(2, 'Ismail', 'Mohamed'),
	(3, 'Julia', 'Kaiser'),
	(4, 'Elias', 'Reichl');