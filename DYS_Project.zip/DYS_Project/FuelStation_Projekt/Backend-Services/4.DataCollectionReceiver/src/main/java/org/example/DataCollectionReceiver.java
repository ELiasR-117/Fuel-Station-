package org.example;

import org.example.Service.Queue;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

// Die Klasse DataCollectionReceiver empfängt Daten von der Warteschlange und verarbeitet sie.
public class DataCollectionReceiver {
    private final Queue queue; // Instanz der Queue-Klasse zur Kommunikation mit RabbitMQ

    // Konstruktor zur Initialisierung des DataCollectionReceiver mit einer Queue-Instanz
    public DataCollectionReceiver(Queue queue) {
        this.queue = queue;
    }

    // Methode zum Warten auf Daten und deren Verarbeitung
    public void waitForData() throws IOException, TimeoutException {
        // Empfängt die erwartete Anzahl von Nachrichten von DataCollectionDispatcher
        this.queue.consumeExpectedMessages();
        // Empfängt die tatsächlichen Nachrichten von StationDataCollector und verarbeitet sie
        this.queue.consumeActualMessages();
    }
}
