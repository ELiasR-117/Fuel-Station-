package org.example;

import org.example.Service.Queue;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

// Die Main-Klasse dient als Einstiegspunkt für die Anwendung.
public class Main {
    // Die main-Methode ist der Einstiegspunkt der Anwendung.
    public static void main(String[] args) throws IOException, TimeoutException {
        // Erstellt eine Instanz der Queue-Klasse.
        Queue queue = new Queue();

        // Erstellt eine Instanz des DataCollectionReceiver mit der Queue-Instanz.
        DataCollectionReceiver dcr = new DataCollectionReceiver(queue);

        // Ruft die waitForData-Methode des DataCollectionReceiver auf, um auf Daten zu warten und diese zu verarbeiten.
        dcr.waitForData();
    }
}
