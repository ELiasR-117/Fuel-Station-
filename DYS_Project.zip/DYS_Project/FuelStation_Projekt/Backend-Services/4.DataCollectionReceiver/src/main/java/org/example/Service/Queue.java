package org.example.Service;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

// Die Klasse Queue stellt Methoden zur Kommunikation mit RabbitMQ-Warteschlangen bereit.
public class Queue {

    // Konstanten zur Konfiguration der RabbitMQ-Warteschlangen und Verbindungsparameter
    private final static String CONSUME1 = "DCD_DCR"; // Warteschlange zum Empfangen von Nachrichten vom DataCollectionDispatcher
    private final static String CONSUME2 = "SDC_DCR"; // Warteschlange zum Empfangen von Nachrichten vom StationDataCollector
    private final static String PRODUCE = "DCR_PG"; // Warteschlange zum Senden von Nachrichten an PDFGenerator
    private final static String HOST = "localhost"; // Hostname des RabbitMQ-Servers
    private final static int PORT = 30003; // Port des RabbitMQ-Servers

    private int expectedCount; // Erwartete Anzahl von Nachrichten
    private int receivedCount = 0; // Tatsächlich empfangene Anzahl von Nachrichten

    private static ConnectionFactory factory; // Factory zur Erstellung von Verbindungen zu RabbitMQ

    // Konstruktor zur Initialisierung der ConnectionFactory mit Host und Port
    public Queue() {
        factory = new ConnectionFactory();
        factory.setHost(HOST);
        factory.setPort(PORT);
    }

    // Methode zum Empfangen der erwarteten Nachrichtenanzahl vom DataCollectionDispatcher
    public void consumeExpectedMessages() throws IOException, TimeoutException {
        Connection connection = factory.newConnection(); // Verbindung zu RabbitMQ herstellen
        Channel channel = connection.createChannel(); // Kanal erstellen

        channel.queueDeclare(CONSUME1, false, false, false, null); // Warteschlange deklarieren
        System.out.println(" [*] Waiting for messages from DataCollectionDispatcher. To exit press CTRL+C");

        // Callback-Funktion zum Verarbeiten empfangener Nachrichten
        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8); // Nachricht lesen
            System.out.println(" [x] Received from DataCollectionDispatcher: '" + message + "' " + LocalTime.now());

            // Nachricht in Schlüssel-Wert-Paare aufteilen und erwartete Nachrichtenanzahl extrahieren
            String[] keyValuePairs = message.split("&");
            for (String keyValuePair : keyValuePairs) {
                String[] parts = keyValuePair.split("=");
                if (parts.length == 2) {
                    String key = parts[0];
                    String value = parts[1];
                    if (key.equals("count")) {
                        expectedCount = Integer.parseInt(value); // Erwartete Nachrichtenanzahl setzen
                    }
                }
            }
            System.out.println("expCount " + expectedCount);
        };

        channel.basicConsume(CONSUME1, true, deliverCallback, consumerTag -> {}); // Nachrichten konsumieren
    }

    // Methode zum Empfangen der tatsächlichen Nachrichten vom StationDataCollector
    public void consumeActualMessages() throws IOException, TimeoutException {
        Connection connection = factory.newConnection(); // Verbindung zu RabbitMQ herstellen
        Channel channel = connection.createChannel(); // Kanal erstellen

        channel.queueDeclare(CONSUME2, false, false, false, null); // Warteschlange deklarieren
        System.out.println(" [*] Waiting for messages from StationDataCollector. To exit press CTRL+C");

        List<String> receivedMessages = new ArrayList<>(); // Liste zur Speicherung der empfangenen Nachrichten

        // Callback-Funktion zum Verarbeiten empfangener Nachrichten
        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8); // Nachricht lesen
            System.out.println(" [x] Received from StationDataCollector: '" + message + "' " + LocalTime.now());
            receivedMessages.add(message); // Nachricht zur Liste hinzufügen
            receivedCount++; // Zähler der empfangenen Nachrichten erhöhen

            // Überprüfen, ob die Anzahl der empfangenen Nachrichten der erwarteten Anzahl entspricht
            if (expectedCount == receivedCount) {
                System.out.println("got this " + receivedMessages);
                try {
                    System.out.println("calculating " + receivedMessages);
                    String customerTotal = calculateTotal(receivedMessages); // Gesamtsumme berechnen
                    send(customerTotal); // Nachricht an PDFGenerator senden
                    receivedCount = 0; // Zähler der empfangenen Nachrichten zurücksetzen
                    receivedMessages.clear(); // Liste der empfangenen Nachrichten leeren
                } catch (TimeoutException e) {
                    throw new RuntimeException(e); // Fehlerbehandlung
                }
            }
        };

        channel.basicConsume(CONSUME2, true, deliverCallback, consumerTag -> {}); // Nachrichten konsumieren
    }

    // Methode zum Senden von Nachrichten an die RabbitMQ-Warteschlange
    private void send(String customerData) throws IOException, TimeoutException {
        try (Connection connection = factory.newConnection(); Channel channel = connection.createChannel()) {
            System.out.println("Publishing " + customerData);
            channel.queueDeclare(PRODUCE, false, false, false, null); // Warteschlange deklarieren
            channel.basicPublish("", PRODUCE, null, customerData.getBytes(StandardCharsets.UTF_8)); // Nachricht senden
            System.out.println(" Sent: '" + customerData + "' to PDFGenerator"); // Nachricht zur Konsole ausgeben
        }
    }

    // Methode zur Berechnung der Gesamtsumme der kWh aus den empfangenen Nachrichten
    public String calculateTotal(List<String> receivedMessages) {
        float totalKWH = 0;
        String id = null;

        // Nachrichten verarbeiten und kWh-Werte summieren
        for (String message : receivedMessages) {
            String[] keyValuePairs = message.split("&");
            for (String keyValuePair : keyValuePairs) {
                String[] parts = keyValuePair.split("=");
                if (parts.length == 2) {
                    String key = parts[0];
                    String value = parts[1];
                    if (key.equals("id")) {
                        id = value;
                    } else if (key.equals("kwh")) {
                        String cleanedValue = value.replaceAll(",", "."); // Kommas entfernen
                        totalKWH += Float.valueOf(cleanedValue); // kWh-Wert zur Gesamtsumme hinzufügen
                    }
                }
            }
        }

        // Gesamtsumme und ID zurückgeben
        if (id != null) {
            System.out.println(totalKWH);
            return "id=" + id + "&totalKWH=" + totalKWH;
        }
        return null;
    }

}
